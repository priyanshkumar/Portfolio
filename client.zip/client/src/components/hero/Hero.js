import React from "react";
import "./Hero.css";

function Hero() {
  return (
    <section className="">
      <div className="hero" />
    </section>
  );
}

export default Hero;
